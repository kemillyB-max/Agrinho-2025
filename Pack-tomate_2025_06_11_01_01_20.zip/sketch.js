let tomatoImg;
const cols = 10;
const rows = 10;
const tileSize = 40;

let agricultor = { x: 1, y: 1 };
let mapa = [];
let produtos = [];
let startTime;
let jogoFinalizado = false;

function preload() {
  // Carrega imagem do tomate (deve estar no projeto com nome tomato.png)
  tomatoImg = loadImage("img/tomate.jpg");
}

function setup() {
  createCanvas(cols * tileSize, rows * tileSize);
  gerarMapa();
  startTime = millis();
}

function draw() {
  background("#e6ffe6");
  desenharMapa();
  desenharAgricultor();
  mostrarTempo();

  if (!jogoFinalizado) {
    colherProduto();
    if (contarTomatesRestantes() === 0) {
      jogoFinalizado = true;
    }
  }

  if (jogoFinalizado) {
    mostrarFimDeJogo();
    noLoop(); // Para o jogo
  }
}

function gerarMapa() {
  mapa = [
    [0,0,0,0,0,0,0,0,0,0],
    [0,1,1,1,0,1,1,1,1,0],
    [0,1,0,1,0,1,0,0,1,0],
    [0,1,0,1,1,1,0,1,1,0],
    [0,1,0,0,0,1,0,1,0,0],
    [0,1,1,1,1,1,0,1,1,0],
    [0,0,0,0,0,1,0,0,1,0],
    [0,1,1,1,0,1,1,1,1,0],
    [0,1,0,1,1,1,0,1,0,0],
    [0,0,0,0,0,0,0,0,0,0]
  ];

  for (let y = 0; y < rows; y++) {
    produtos[y] = [];
    for (let x = 0; x < cols; x++) {
      produtos[y][x] = mapa[y][x] === 1;
    }
  }
}

function desenharMapa() {
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (mapa[y][x] === 0) {
        fill(100, 150, 100); // Obstáculo
      } else {
        fill(230, 255, 230); // Caminho
      }
      rect(x * tileSize, y * tileSize, tileSize, tileSize);

      if (produtos[y][x]) {
        image(tomatoImg, x * tileSize + 8, y * tileSize + 8, tileSize - 16, tileSize - 16);
      }
    }
  }
}

function desenharAgricultor() {
  fill(139, 69, 19); // marrom (agricultor)
  ellipse(agricultor.x * tileSize + tileSize / 2, agricultor.y * tileSize + tileSize / 2, tileSize * 0.8);
}

function keyPressed() {
  if (jogoFinalizado) return;

  let novoX = agricultor.x;
  let novoY = agricultor.y;

  if (keyCode === LEFT_ARROW) novoX--;
  if (keyCode === RIGHT_ARROW) novoX++;
  if (keyCode === UP_ARROW) novoY--;
  if (keyCode === DOWN_ARROW) novoY++;

  if (mapa[novoY] && mapa[novoY][novoX] === 1) {
    agricultor.x = novoX;
    agricultor.y = novoY;
  }
}

function colherProduto() {
  if (produtos[agricultor.y][agricultor.x]) {
    produtos[agricultor.y][agricultor.x] = false;
  }
}

function contarTomatesRestantes() {
  let contador = 0;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (produtos[y][x]) contador++;
    }
  }
  return contador;
}

function mostrarTempo() {
  let tempoDecorrido = (millis() - startTime) / 1000;
  fill(0);
  textSize(16);
  textAlign(LEFT, TOP);
  text(`Tempo: ${tempoDecorrido.toFixed(1)}s`, 10, 10);
}

function mostrarFimDeJogo() {
  let tempoFinal = (millis() - startTime) / 1000;
  fill(0);
  textSize(28);
  textAlign(CENTER, CENTER);
  text(`Você colheu todos os tomates! 🧺\nTempo total: ${tempoFinal.toFixed(2)} segundos`, width / 2, height / 2);
}
